<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<center>
		<form method="post" action="insert.php" enctype="multipart/form-data">
			<table>
				<tr>
					<td>name</td>
					<td><input type="text" name="name"></td>
				</tr>
				<tr>
					<td>email</td>
					<td><input type="email" name="email"></td>
				</tr>
				<tr>
					<td>salary</td>
					<td><input type="number" name="salary"></td>
				</tr>
				<tr>
					<td>image</td>
					<td><input type="file" name="image"></td>
				</tr>
				<tr>
					<td>&nbsp</td>
					<td><input type="submit" name="submit" value="submit"></td>
				</tr>
			</table>
		</form>
	</center>
</body>
</html>