<?php

include "conn.php";

$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$salary=$_REQUEST['salary'];
$image=$_FILES['image']['name'];
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,"image/".$image);

$insert="INSERT INTO `info` (`name`,`email`,`salary`,`image`) VALUES ('".$name."','".$email."','".$salary."','".$image."')";

$qry=mysqli_query($conn,$insert);

if($qry)
{
	echo "inserted successfully";
}
else
{
	echo "not inserted";
}

?>