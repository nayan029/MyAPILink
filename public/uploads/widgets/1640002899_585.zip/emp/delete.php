<?php

include "conn.php";

$delete="DELETE FROM `info` where `id`='".$_REQUEST['id']."'";

$qry=mysqli_query($conn,$delete);

if($qry)
{
	echo "deleted successfully";
}
else
{
	echo "not deleted";
}




?>