<?php

include "conn.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table border="10">
		<thead>
			<th>no</th>
			<th>name</th>
			<th>email</th>
			<th>salary</th>
			<th>image</th>
			<th colspan="2">action</th>
		</thead>
		<tbody>
			<?php
				$i=1;
				$select="SELECT * FROM `info`";
				$qry=mysqli_query($conn,$select);
				while($row=mysqli_fetch_assoc($qry))
				{

			?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $row['name']; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td><?php echo $row['salary']; ?></td>
				<td><img src="<?php echo "image/".$row['image'];?>" height="50px" width="50px"></td>
				<td><a href="updateform.php?id=<?php echo $row['id']; ?>">update</a></td>
    			<td><a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>
			</tr>

			<?php $i++; } ?>
		</tbody>
	</table>

</body>
</html>